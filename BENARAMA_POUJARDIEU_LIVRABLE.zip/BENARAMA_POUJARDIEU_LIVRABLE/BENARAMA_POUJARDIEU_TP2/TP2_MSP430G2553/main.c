#include <msp430.h> 
#include <string.h>


void init_BOARD( void );
void init_UART( void );
void init_USCI( void );
void interpreteur( void );
void envoi_msg_UART(unsigned char * );
void Send_char_SPI( unsigned char );



#define RELEASE "\r\t\tSPI-rIII162018"
#define PROMPT  "\r\nmaster>"
#define CMDLEN  10

#define TRUE    1
#define FALSE   0

#define LF      0x0A
#define CR      0x0D
#define BSPC    0x08
#define DEL     0x7F
#define ESC     0x1B

#define _CS         BIT4
#define SCK         BIT5
#define DATA_OUT    BIT6
#define DATA_IN     BIT7

#define LED_R       BIT0
#define LED_G       BIT6



unsigned char cmd[CMDLEN];
unsigned char car = 0x30;
unsigned int  nb_car = 0;
unsigned char intcmd = FALSE;



void interpreteur( void )
{
    if(strcmp((const char *)cmd, "h") == 0)
    {
        envoi_msg_UART("\r\nCommandes :");
        envoi_msg_UART("\r\n'ver' : version");
        envoi_msg_UART("\r\n'0' : LED off");
        envoi_msg_UART("\r\n'1' : LED on");
        envoi_msg_UART("\r\n'h' : help\r\n");
    }
    else if (strcmp((const char *)cmd, "0") == 0)
    {
        envoi_msg_UART("\r\n");
        envoi_msg_UART((unsigned char *)cmd);
        envoi_msg_UART("->");
        Send_char_SPI(0x30);
        envoi_msg_UART("\r\n");
    }
    else if (strcmp((const char *)cmd, "1") == 0)
    {
        envoi_msg_UART("\r\n");
        envoi_msg_UART((unsigned char *)cmd);
        envoi_msg_UART("->");
        Send_char_SPI(0x31);
        envoi_msg_UART("\r\n");
    }
    else if (strcmp((const char *)cmd, "ver") == 0)
    {
        envoi_msg_UART("\r\n");
        envoi_msg_UART(RELEASE);
        envoi_msg_UART("\r\n");
    }
    else
    {
        envoi_msg_UART("\r\n ?");
        envoi_msg_UART((unsigned char *)cmd);
    }
    envoi_msg_UART(PROMPT);
}



void init_BOARD( void )
{
    WDTCTL = WDTPW | WDTHOLD;

    if( (CALBC1_1MHZ==0xFF) || (CALDCO_1MHZ==0xFF) )
    {
        __bis_SR_register(LPM4_bits);
    }
    else
    {
        DCOCTL = 0;
        BCSCTL1 = CALBC1_1MHZ;
        DCOCTL = (0 | CALDCO_1MHZ);
    }

    P1SEL  = 0x00;
    P1SEL2 = 0x00;
    P2SEL  = 0x00;
    P2SEL2 = 0x00;
    P1DIR = 0x00;
    P2DIR = 0x00;

    P1SEL  &= ~LED_R;
    P1SEL2 &= ~LED_R;
    P1DIR |= LED_R ;
    P1OUT &= ~LED_R ;
}



void init_UART( void )
{
    P1SEL  |= (BIT1 | BIT2);
    P1SEL2 |= (BIT1 | BIT2);
    UCA0CTL1 |= UCSWRST;
    UCA0CTL1 |= UCSSEL_2;
    UCA0BR0 = 104;
    UCA0BR1 = 0;
    UCA0MCTL = 10;
    UCA0CTL0 &= ~(UCPEN  | UCMSB | UCDORM);
    UCA0CTL0 &= ~(UC7BIT | UCSPB  | UCMODE_3 | UCSYNC);
    UCA0CTL1 &= ~UCSWRST;

    IE2 |= UCA0RXIE;
}



void init_USCI( void )
{
    // Waste Time, waiting Slave SYNC
    __delay_cycles(250);

    // SOFTWARE RESET - mode configuration
    UCB0CTL0 = 0;
    UCB0CTL1 = (0 + UCSWRST*1 );

    IFG2 &= ~(UCB0TXIFG | UCB0RXIFG);

    UCB0CTL0 |= ( UCMST | UCMODE_0 | UCSYNC );
    UCB0CTL0 &= ~( UCCKPH | UCCKPL | UCMSB | UC7BIT );
    UCB0CTL1 |= UCSSEL_2;

    UCB0BR0 = 0x0A;
    UCB0BR1 = 0x00;

    P1SEL  |= ( SCK | DATA_OUT | DATA_IN);
    P1SEL2 |= ( SCK | DATA_OUT | DATA_IN);

    UCB0CTL1 &= ~UCSWRST;
}



void envoi_msg_UART(unsigned char *msg)
{
    unsigned int i = 0;
    for(i=0 ; msg[i] != 0x00 ; i++)
    {
        while(!(IFG2 & UCA0TXIFG));
        UCA0TXBUF=msg[i];
    }
}



void Send_char_SPI(unsigned char carac)
{
    while ((UCB0STAT & UCBUSY));
    while(!(IFG2 & UCB0TXIFG));
    UCB0TXBUF = carac;
    envoi_msg_UART((unsigned char *)cmd);
}



void main( void )
{
    init_BOARD();
    init_UART();
    init_USCI();

    envoi_msg_UART("\rReady !\r\n");
    envoi_msg_UART(PROMPT);

 while(1)
    {
        if( intcmd )
        {
            while ((UCB0STAT & UCBUSY));
            interpreteur();
            intcmd = FALSE;
        }
        else
        {
            __bis_SR_register(LPM4_bits | GIE);
        }
    }
}


#pragma vector = USCIAB0RX_VECTOR
__interrupt void USCIAB0RX_ISR()
{
    if (IFG2 & UCA0RXIFG)
    {
        while(!(IFG2 & UCA0RXIFG));
        cmd[nb_car]=UCA0RXBUF;

        while(!(IFG2 & UCA0TXIFG));
        UCA0TXBUF = cmd[nb_car];

        if( cmd[nb_car] == ESC)
        {
            nb_car = 0;
            cmd[1] = 0x00;
            cmd[0] = CR;
        }

        if( (cmd[nb_car] == CR) || (cmd[nb_car] == LF))
        {
            cmd[nb_car] = 0x00;
            intcmd = TRUE;
            nb_car = 0;
            __bic_SR_register_on_exit(LPM4_bits);
        }
        else if( (nb_car < CMDLEN) && !((cmd[nb_car] == BSPC) || (cmd[nb_car] == DEL)) )
        {
            nb_car++;
        }
        else
        {
            cmd[nb_car] = 0x00;
            nb_car--;
        }
    }
    else if (IFG2 & UCB0RXIFG)
    {
        while( (UCB0STAT & UCBUSY) && !(UCB0STAT & UCOE) );
        while(!(IFG2 & UCB0RXIFG));
        cmd[0] = UCB0RXBUF;
        cmd[1] = 0x00;
        P1OUT ^= LED_R;
    }
}
