#include <msp430.h> 
#include <string.h>


void init_BOARD( void );
void init_USCI( void );
void Send_char_SPI( unsigned char );

#define CMDLEN  10

#define TRUE    1
#define FALSE   0

#define LF      0x0A
#define CR      0x0D
#define BSPC    0x08
#define DEL     0x7F
#define ESC     0x1B

#define _CS         BIT4
#define SCK         BIT5
#define DATA_OUT    BIT6
#define DATA_IN     BIT7

#define LED_R       BIT0
#define LED_G       BIT6


unsigned char cmd[CMDLEN];


void init_BOARD( void )
{
    WDTCTL = WDTPW | WDTHOLD;

    if( (CALBC1_1MHZ==0xFF) || (CALDCO_1MHZ==0xFF) )
    {
        __bis_SR_register(LPM4_bits);
    }
    else
    {
        DCOCTL = 0;
        BCSCTL1 = CALBC1_1MHZ;
        DCOCTL = (0 | CALDCO_1MHZ);
    }

    P1SEL  = 0x00;
    P1SEL2 = 0x00;
    P2SEL  = 0x00;
    P2SEL2 = 0x00;
    P1DIR = 0x00;
    P2DIR = 0x00;

    P1SEL  &= ~LED_R;
    P1SEL2 &= ~LED_R;
    P1DIR |= LED_R ;
    P1OUT &= ~LED_R ;
}


void init_USCI( void )
{
    __delay_cycles(250);

    UCB0CTL0 = 0;
    UCB0CTL1 = (0 + UCSWRST*1 );

    IFG2 &= ~(UCB0TXIFG | UCB0RXIFG);

    // Configuration SPI (voir slau144 p.445)
    // UCCKPH = 0 -> Data changed on leading clock edges and sampled on trailing edges.
    // UCCKPL = 0 -> Clock inactive state is low.
    //   SPI Mode 0 :  UCCKPH * 1 | UCCKPL * 0
    //   SPI Mode 1 :  UCCKPH * 0 | UCCKPL * 0  <--
    //   SPI Mode 2 :  UCCKPH * 1 | UCCKPL * 1
    //   SPI Mode 3 :  UCCKPH * 0 | UCCKPL * 1
    // UCMSB  = 1 -> MSB premier
    // UC7BIT = 0 -> 8 bits, 1 -> 7 bits
    // UCMST  = 0 -> CLK by Master, 1 -> CLK by USCI bit CLK / p441/16.3.6
    // UCMODE_x  x=0 -> 3-pin SPI,
    //           x=1 -> 4-pin SPI UC0STE active high,
    //           x=2 -> 4-pin SPI UC0STE active low,
    //           x=3 -> i�c.
    // UCSYNC = 1 -> Mode synchrone (SPI)
    UCB0CTL0 |= ( UCMST | UCMODE_0 | UCSYNC );
    UCB0CTL0 &= ~( UCCKPH | UCCKPL | UCMSB | UC7BIT );
    UCB0CTL1 |= UCSSEL_2;

    UCB0BR0 = 0x0A;     // divide SMCLK by 10
    UCB0BR1 = 0x00;

    // SPI : Fonctions secondaires
    // MISO-1.6 MOSI-1.7 et CLK-1.5
    // Ref. SLAS735G p48,49
    P1SEL  |= (SCK | DATA_OUT | DATA_IN);
    P1SEL2 |= (SCK | DATA_OUT | DATA_IN);

    UCB0CTL1 &= ~UCSWRST;

    IE2 |= (UCB0RXIE);
}


void Send_char_SPI(unsigned char carac)
{
    while ((UCB0STAT & UCBUSY));
    while(!(IFG2 & UCB0TXIFG));
    UCB0TXBUF = carac;
}



void main( void )
{
    init_BOARD();
    init_USCI();

    while(1)
    {
        P1OUT ^= LED_R;
        __delay_cycles(7500000);
        Send_char_SPI(0x31);
    }
}


#pragma vector = USCIAB0RX_VECTOR
__interrupt void USCIAB0RX_ISR()
{
    if (IFG2 & UCB0RXIFG)
    {
        while( (UCB0STAT & UCBUSY) && !(UCB0STAT & UCOE) );
        while(!(IFG2 & UCB0RXIFG));
        cmd[0] = UCB0RXBUF;
        cmd[1] = 0x00;
        IFG2 &= ~(UCB0RXIFG);
    }
}


