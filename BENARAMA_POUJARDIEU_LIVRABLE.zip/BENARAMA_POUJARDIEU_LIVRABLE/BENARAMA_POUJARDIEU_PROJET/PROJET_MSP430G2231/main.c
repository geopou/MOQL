#include <msp430.h> 
#include <intrinsics.h>

volatile unsigned char RXDta;
int valeur = 0;
unsigned char i, j;
int lecture = 0;

void init_BOARD(void);
void init_PORT1(void);
void init_SPI_slave(void);


void init_BOARD(void)
{
    WDTCTL = WDTPW | WDTHOLD;

    if(CALBC1_1MHZ==0xFF || CALDCO_1MHZ==0xFF)
    {
        __bis_SR_register(LPM4_bits);
    }
    else
    {
        DCOCTL = 0;
        BCSCTL1 = CALBC1_1MHZ;
        DCOCTL = (0 | CALDCO_1MHZ);
    }
}

void init_PORT1(void)
{
    P1SEL = 0x00;
    P1DIR = 0x00;

    P1DIR |=  BIT0;
    P1OUT &= ~BIT0;
}

void init_SPI_slave(void)
{
    USICTL0 |= USISWRST;
    USICTL1 = 0;

    USICTL0 |= (USIPE7 | USIPE6 | USIPE5 | USILSB | USIOE | USIGE );
    USICTL0 &= ~(USIMST);
    USICTL1 |= USIIE;
    USICTL1 &= ~(USICKPH | USII2C);

    USICKCTL = 0;
    USICKCTL &= ~(USICKPL | USISWCLK);

    USICNT = 0;
    USICNT &= ~(USI16B | USIIFGCC );
    USISRL = 0x23;
    USICNT = 0x08;
}


void main( void )
{
    init_BOARD();
    init_PORT1();
    init_SPI_slave();
    ADC_init();

    __bis_SR_register(LPM4_bits | GIE);
}


#pragma vector=USI_VECTOR
__interrupt void universal_serial_interface(void)
{
    while(!(USICTL1 & USIIFG));
    RXDta = USISRL;

    if (RXDta == 0x31)
    {
        P1OUT ^= BIT0;
        for(i=0;i<10;i++)
        {
            ADC_Demarrer_conversion(4);
            valeur = valeur + ADC_Lire_resultat();
        }
        lecture = valeur / 40;
        valeur = 0;
    }
    else
    {
        lecture = 0x0001;
    }

    USISRL = (unsigned char) lecture;
    USICNT &= ~USI16B;
    USICNT = 0x08;
    USICTL0 &= ~USISWRST;
}

