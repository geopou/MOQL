#include <msp430.h> 

void InitUART(void)
{
    P1SEL |= (BIT1 | BIT2);
    P1SEL2 |= (BIT1 | BIT2);
    UCA0CTL1 = UCSWRST;
    UCA0CTL1 |= UCSSEL_3;

    UCA0CTL0 &= ~(UCPEN | UCMSB | UCDORM);
    UCA0CTL0 &= ~(UC7BIT | UCSPB | UCMODE_3 | UCSYNC);
    UCA0CTL1 &= ~UCSWRST;

    UCA0BR0 = 104;
    UCA0BR1 = 0;
    UCA0MCTL = 10;

    IE2 |= UCA0RXIE;
}

void TXdata( unsigned char c )
{
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = c;
}



void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;
	
	if(CALBC1_1MHZ==0xFF || CALDCO_1MHZ==0xFF)
	{
	    __bis_SR_register(LPM4_bits);
    }
    else
    {
        BCSCTL1 = CALBC1_1MHZ;
        DCOCTL = CALDCO_1MHZ;
    }

    InitUART();

    __bis_SR_register(GIE);

    TXdata('>');
    while(1);
}


#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{
    unsigned char c;

    c = UCA0RXBUF;
    TXdata(c);
}

